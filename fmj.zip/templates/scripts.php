<!-- JQUERY -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<!-- BOOSTRAP -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
<!-- FONTAWESOME -->
<script src="https://kit.fontawesome.com/acd09bc297.js" crossorigin="anonymous"></script>
<!-- SWEET ALERT -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>
<!-- BOOTSTRAP DATEPICKER -->
<script src="js/plugins/datepicker.js"></script>
<!-- DATA-TABLES -->
<script src="js/plugins/jquery-paginate.js"></script>
<!-- TABLE SORTER -->
<script src="js/plugins/jquery.tablesorter.min.js"></script>
<script src="js/plugins/jquery.tablesorter.widgets.min.js"></script>
<!-- MAIN -->
<script src="js/main.js?v=1"></script>
<!--LIGHTBOX-->
<script src="js/lightbox.js"></script>