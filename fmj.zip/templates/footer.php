<footer class="footer">
    <div class="container">
        <div class="container-footer text-center copyright">
            <div class="col-7 texto-footer">Copyright © Torneo Interfederativo de Judo 2020</div>
            <a href="administracion/login.php"><div class="texto-footer panel">Panel de Administración</div></a>
        </div>
    </div>

    <hr class="linea-footer">

    <div class="text-center spam">
        <a href="https://smtechnology.com.ar">Diseño Web by <span class="smt">SMT</span></a>
    </div>
</footer>