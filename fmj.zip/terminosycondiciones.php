<!DOCTYPE html>
<html lang="es">

    <!-- HEAD -->
    <?php include 'templates/head.php' ?>

    <body>
        <!-- HEADER -->
        <?php include 'templates/header.php' ?>
        <!-- SECCION PATROCINADORES-->
        <section class="container">
            <div class="descripcion">
                <h2 class="titulo-body">TÉRMINOS Y CONDICIONES</h2>
            </div>
            <div class="terminos">
            </div>
        </section>
        <!-- FOOTER -->
        <?php include 'templates/footer.php' ?>
        <!-- SCRIPTS -->
        <?php include 'templates/scripts.php' ?>
    </body>

</html>