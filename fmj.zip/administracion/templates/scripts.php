<!-- jQuery -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<!-- Bootstrap -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
<!-- Bootstrap Datepicker -->
<script src="../js/plugins/datepicker.js"></script>
<!-- DataTables -->
<script src="../js/plugins/jquery-paginate.js"></script>
<!-- FontAwesome -->
<script src="https://kit.fontawesome.com/acd09bc297.js" crossorigin="anonymous"></script>
<!-- Sweet Alert -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>
<!-- Main -->
<script src="js/main.js?v=1"></script>