<footer id="footer-login" class="d-flex justify-content-center align-items-center">
    <div class="text-center spam">
        <a href="https://smtechnology.com.ar" target="_blank">Diseño Web by <span class="smt">SMT</span></a>
    </div>
</footer>