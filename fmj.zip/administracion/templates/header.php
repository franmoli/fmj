<header id="header-admin">   
    <div class="row align-items-center">
        <div class="col-md-2 imagen text-center">
            <a href="index.php"><img src="../img/logo2.jpeg" alt="Torneo Interfederativo de Judo"></a>
        </div>
        <div class="col-md-10 titulos text-center">
            <h1>Torneo Interfederativo de Judo</h1>
            <hr>
            <h1>Panel de Administración</h1>
        </div>
    </div>
</header>